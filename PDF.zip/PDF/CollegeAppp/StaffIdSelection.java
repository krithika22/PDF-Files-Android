package com.CollegeAppp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class StaffIdSelection extends Activity implements OnItemSelectedListener{
	
	private String selectedStaffId = null;
	private StringTokenizer stringToken = null;
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staffidselection);
        
        Button btn_staff_selection_submit = (Button)findViewById(R.id.btn_staff_selection_submit);
        Spinner staff_select_id_spinner = (Spinner)findViewById(R.id.staff_id_spinner);
        String str = getPostdata("SELECTSTAFFID");
        List list = new ArrayList();
        /* if(str!=null && str.startsWith("RESULT$")){
        	stringToken = new StringTokenizer(str,"$");
        	stringToken.nextToken();
        	
        	while(stringToken.hasMoreTokens()){
        		list.add(stringToken.nextToken());
        	}
        }else{
        	Toast.makeText(getApplicationContext(), "No data found",Toast.LENGTH_LONG).show();
        }*/
        //list.add(LoggerEntity.getdepartment());
        String dept=LoggerEntity.getdepartment().toString();
        list.add(dept);
        list.add("ALL");
        
    	
    	
    	staff_select_id_spinner.setOnItemSelectedListener(this);
    	ArrayAdapter dataAdpter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,list);
    	dataAdpter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    	staff_select_id_spinner.setAdapter(dataAdpter);
    	
    	btn_staff_selection_submit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(selectedStaffId!=null){
				     LoggerEntity.setSelectedStaffId(selectedStaffId);
				if(LoggerEntity.getAction().equals("ASKQUESTIONS")){
					finish();
					//Intent intent = new Intent(StaffIdSelection.this,StaffQueriesAnswer.class);
					//startActivity(intent);
				}else if(LoggerEntity.getAction().equals("ANSWERS")){
					
				}else {
				String result = getFileNames(LoggerEntity.getSelectedStaffId(),LoggerEntity.getAction());
				if(result!=null && result.startsWith("FILENAME$$")){
					LoggerEntity.setFileNames(result);
					
					finish();
					Toast.makeText(getApplicationContext(), result, 10).show();
					Intent intent = new Intent(StaffIdSelection.this,FileList.class);
					startActivity(intent);
					
				}else{
					Toast.makeText(getApplicationContext(), "No File Found", Toast.LENGTH_LONG).show();
				}
				}
				}else{
					Toast.makeText(getApplicationContext(), "selected staff id is null",Toast.LENGTH_LONG).show();
				}
			}
		});
	}
	
	public void onItemSelected(AdapterView<?> parent,View view,int pos,long id){
		selectedStaffId = parent.getItemAtPosition(pos).toString();
		//Toast.makeText(getApplicationContext(), "Selected Staff Id..."+selectedStaffId,Toast.LENGTH_LONG).show();
	}
	
	public void onNothingSelected(AdapterView<?> parent){
		
	}
	
	
	private String getPostdata(String userid){
    	try{
            ArrayList<BasicNameValuePair> namevaluepair=new ArrayList<BasicNameValuePair>();
            namevaluepair.add(new BasicNameValuePair("StaffID", userid));
            
            
            
            
                      
            HttpClient client=new DefaultHttpClient();
            HttpPost post=new HttpPost("http://"+LoggerEntity.getIpaddress()+":8080/CollegeApp/StaffSelectId.jsp");
            post.setEntity(new UrlEncodedFormEntity(namevaluepair));
            HttpResponse response=client.execute(post);
            HttpEntity entity=response.getEntity();
            InputStream in=entity.getContent();
            try{
                BufferedReader bf=new BufferedReader(new InputStreamReader(in));
                StringBuilder sb=new StringBuilder();
                String line=null;
                while((line=bf.readLine())!=null){

                    sb.append(line);

                }
                String result=sb.toString().trim();
              //  Toast.makeText(getApplicationContext(), "Result..."+result,Toast.LENGTH_SHORT).show();
              return result;
            }catch(Exception e){
                e.printStackTrace();
            }
        }catch(Exception e){
            System.out.println("Error in http"+e.toString());
        }
    	return null;
    }

	
	private String getFileNames(String userid,String actionMode){
    	try{
            ArrayList<BasicNameValuePair> namevaluepair=new ArrayList<BasicNameValuePair>();
            namevaluepair.add(new BasicNameValuePair("staffId", userid));
            namevaluepair.add(new BasicNameValuePair("actionString", actionMode));
            
            
            
                      
            HttpClient client=new DefaultHttpClient();
            HttpPost post=new HttpPost("http://"+LoggerEntity.getIpaddress()+":8080/CollegeApp/FileNameList.jsp");
            post.setEntity(new UrlEncodedFormEntity(namevaluepair));
            HttpResponse response=client.execute(post);
            HttpEntity entity=response.getEntity();
            InputStream in=entity.getContent();
            try{
                BufferedReader bf=new BufferedReader(new InputStreamReader(in));
                StringBuilder sb=new StringBuilder();
                String line=null;
                while((line=bf.readLine())!=null){

                    sb.append(line);

                }
                String result=sb.toString().trim();
              //  Toast.makeText(getApplicationContext(), "Result..."+result,Toast.LENGTH_SHORT).show();
              return result;
            }catch(Exception e){
                e.printStackTrace();
            }
        }catch(Exception e){
            System.out.println("Error in http"+e.toString());
        }
    	return null;
    }


}
