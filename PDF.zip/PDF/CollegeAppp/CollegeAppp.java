package com.CollegeAppp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;

public class CollegeAppp extends Activity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = 
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
     
        Button btn_student_login = (Button)findViewById(R.id.btn_student_login);
        Button btn_exit = (Button)findViewById(R.id.btn_exit);
        
      
        
        btn_student_login.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				LoggerEntity.setActionMode("STUDENTLOGIN");
				finish();
				Intent intent = new Intent(CollegeAppp.this,UserLogin.class);
				startActivity(intent);
			}
		});

        btn_exit.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		finish();
		System.exit(0);
	}
});

        
    }

}
