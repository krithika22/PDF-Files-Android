package com.CollegeAppp;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserLogin extends Activity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Button btn_signin = (Button)findViewById(R.id.btn_signin);
        final EditText txt_uname = (EditText)findViewById(R.id.txt_signin_accno);
        final EditText txt_signin_password = (EditText)findViewById(R.id.txt_signin_password);
        final EditText txt_signin_ipaddress = (EditText)findViewById(R.id.txt_signin_ipaddress);
        
        btn_signin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String uname = txt_uname.getText().toString();
				String password = txt_signin_password.getText().toString();
				String ipaddress = txt_signin_ipaddress.getText().toString();
				if(!"".equals(uname) && !"".equals(password)&&!"".equals(ipaddress)){
					LoggerEntity.setIpaddress(ipaddress);
					
					String result = getPostdata(uname,password);
					Toast.makeText(getApplicationContext(), result, 10).show();
					if(result!=null && result.startsWith("VALID$")){
						StringTokenizer stringToken = new StringTokenizer(result,"$");
						stringToken.nextToken();
						String staffId = stringToken.nextToken();
						String Department = stringToken.nextToken();
						LoggerEntity.setdepartment(Department);
						Toast.makeText(getApplicationContext(), Department, 10).show();
						if(LoggerEntity.getActionMode()!=null && LoggerEntity.getActionMode().equals("STAFFLOGIN")){
							LoggerEntity.setStaffId(staffId);
							
							//Intent intent = new Intent(UserLogin.this,StaffMenu.class);
							//startActivity(intent);
						}else if(LoggerEntity.getActionMode()!=null && LoggerEntity.getActionMode().equals("STUDENTLOGIN")){
							LoggerEntity.setStudentId(staffId);
							
							Intent intent = new Intent(UserLogin.this,StudentMenu.class);
							startActivity(intent);
						}
						
						
					}else{
						Toast.makeText(getApplicationContext(), "Invalid username and password", Toast.LENGTH_LONG).show();
					}
					
					
				}else{
					Toast.makeText(getApplicationContext(), "Please fill all the fields", Toast.LENGTH_LONG).show();
				}
				
			}
		});
        
    }
    
    private String getPostdata(String userid,String pass){
    	try{
            ArrayList<BasicNameValuePair> namevaluepair=new ArrayList<BasicNameValuePair>();
            namevaluepair.add(new BasicNameValuePair("userid", userid));
            namevaluepair.add(new BasicNameValuePair("pass", pass));
            namevaluepair.add(new BasicNameValuePair("role", LoggerEntity.getActionMode()));
            
            
            
                      
            HttpClient client=new DefaultHttpClient();
            HttpPost post=new HttpPost("http://"+LoggerEntity.getIpaddress()+":8080/CollegeApp/MobileLogin.jsp");
            post.setEntity(new UrlEncodedFormEntity(namevaluepair));
            HttpResponse response=client.execute(post);
            HttpEntity entity=response.getEntity();
            InputStream in=entity.getContent();
            try{
                BufferedReader bf=new BufferedReader(new InputStreamReader(in));
                StringBuilder sb=new StringBuilder();
                String line=null;
                while((line=bf.readLine())!=null){

                    sb.append(line);

                }
                String result=sb.toString().trim();
              //  Toast.makeText(getApplicationContext(), "Result..."+result,Toast.LENGTH_SHORT).show();
              return result;
            }catch(Exception e){
                e.printStackTrace();
            }
        }catch(Exception e){
            System.out.println("Error in http"+e.toString());
        }
    	return null;
    }


}
