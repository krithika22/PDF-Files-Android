package com.CollegeAppp;

public class LoggerEntity {
	
	public static String actionMode = null;
	public static String ipaddress = null;
	public static String action = null;
	public static String fileNames = null;
	public static String fileContent = null;
	public static String questions = null;
	public static String questionId = null;
	public static String answers = null;
	public static String department = null;
	public static String url = null;
	
	public static String getdepartment() {
		return department;
	}

	public static void setdepartment(String department) {
		LoggerEntity.department = department;
	}
	
	public static String geturl() {
		return url;
	}

	public static void seturl(String url) {
		LoggerEntity.url = url;
	}
	
	
	public static String getAnswers() {
		return answers;
	}

	public static void setAnswers(String answers) {
		LoggerEntity.answers = answers;
	}

	public static String getQuestionId() {
		return questionId;
	}

	public static void setQuestionId(String questionId) {
		LoggerEntity.questionId = questionId;
	}

	public static String getQuestions() {
		return questions;
	}

	public static void setQuestions(String questions) {
		LoggerEntity.questions = questions;
	}

	public static String getFileContent() {
		return fileContent;
	}

	public static void setFileContent(String fileContent) {
		LoggerEntity.fileContent = fileContent;
	}

	public static String selectedStaffId = null;
	public static String getSelectedStaffId() {
		return selectedStaffId;
	}

	public static void setSelectedStaffId(String selectedStaffId) {
		LoggerEntity.selectedStaffId = selectedStaffId;
	}

	public static String getFileNames() {
		return fileNames;
	}

	public static void setFileNames(String fileNames) {
		LoggerEntity.fileNames = fileNames;
	}

	public static String getAction() {
		return action;
	}

	public static void setAction(String action) {
		LoggerEntity.action = action;
	}

	public static String getStudentId() {
		return studentId;
	}

	public static void setStudentId(String studentId) {
		LoggerEntity.studentId = studentId;
	}

	public static String getStaffId() {
		return staffId;
	}

	public static void setStaffId(String staffId) {
		LoggerEntity.staffId = staffId;
	}

	public static String studentId = null;
	public static String staffId = null;

	public static String getIpaddress() {
		return ipaddress;
	}

	public static void setIpaddress(String ipaddress) {
		LoggerEntity.ipaddress = ipaddress;
	}

	public static String getActionMode() {
		return actionMode;
	}

	public static void setActionMode(String actionMode) {
		LoggerEntity.actionMode = actionMode;
	}
	

}
