package com.CollegeAppp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

public class FileList extends ListActivity{
	static String text = "";
	
	public void onCreate(Bundle savedInstanceState) {
	   super.onCreate(savedInstanceState);
	  
	   String message = LoggerEntity.getFileNames();
 	   //Toast.makeText(getApplicationContext(), "MEssage...."+message, Toast.LENGTH_LONG).show();
	    StringTokenizer st = new StringTokenizer(message,"$$");
	    st.nextToken();
	    ArrayList<String> al = new ArrayList<String>();
	    while(st.hasMoreTokens()){
	    	String data = (String)st.nextToken();
	    	//data = data.replace("<br>", "\n");
		  al.add(data);
		   
	   }
	    //al.add("Back");
	   Log.v("Search output",al.toString());
	   setListAdapter(new ArrayAdapter<String>(this, R.layout.list_item, al));

	   ListView lv = getListView();
	   lv.setTextFilterEnabled(true);

	   lv.setOnItemClickListener(new OnItemClickListener() {
	     public void onItemClick(AdapterView<?> parent, View view,
	         int position, long id) {
	      	String selectedText = ((TextView) view).getText().toString();
	      	 if(selectedText.intern() == "Back"){
	      	
	      	 }else{
	      		text = selectedText;
	      		String data = getPostdata(text);
	      		if(data!=null && !data.equals("NOFILEFOUND")){
	      			LoggerEntity.setFileContent(data);
	      			finish();
	      			Toast.makeText(getApplicationContext(), "IpAddress"+LoggerEntity.getIpaddress(), 10).show();
	      			Toast.makeText(getApplicationContext(), "FileName"+LoggerEntity.getFileNames(), 10).show();
	      			LoggerEntity.seturl("http://"+LoggerEntity.getIpaddress()+":8080/uploads/"+LoggerEntity.getSelectedStaffId()+"/"+text);
	      			Intent intent = new Intent(FileList.this,ViewBrowser.class);
	      			startActivity(intent);
	      		}else{
	      			Toast.makeText(getApplicationContext(), "No Data Found", Toast.LENGTH_LONG).show();
	      		}
	      	 }
	       }
	   });
	 }
	
	
	 private String getPostdata(String fileName){
	    	try{
	            ArrayList<BasicNameValuePair> namevaluepair=new ArrayList<BasicNameValuePair>();
	            namevaluepair.add(new BasicNameValuePair("userid", LoggerEntity.getSelectedStaffId()));
	            namevaluepair.add(new BasicNameValuePair("fileName", fileName));
	            namevaluepair.add(new BasicNameValuePair("actionString", LoggerEntity.getAction()));
	            
	            
	            
	                      
	            HttpClient client=new DefaultHttpClient();
	            HttpPost post=new HttpPost("http://"+LoggerEntity.getIpaddress()+":8080/CollegeApp/ViewFileName.jsp");
	            post.setEntity(new UrlEncodedFormEntity(namevaluepair));
	            HttpResponse response=client.execute(post);
	            HttpEntity entity=response.getEntity();
	            InputStream in=entity.getContent();
	            try{
	                BufferedReader bf=new BufferedReader(new InputStreamReader(in));
	                StringBuilder sb=new StringBuilder();
	                String line=null;
	                while((line=bf.readLine())!=null){

	                    sb.append(line);

	                }
	                String result=sb.toString().trim();
	              //  Toast.makeText(getApplicationContext(), "Result..."+result,Toast.LENGTH_SHORT).show();
	              return result;
	            }catch(Exception e){
	                e.printStackTrace();
	            }
	        }catch(Exception e){
	            System.out.println("Error in http"+e.toString());
	        }
	    	return null;
	    }

}

