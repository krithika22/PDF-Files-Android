package com.CollegeAppp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class StudentMenu extends Activity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studentmenu);
        
        Button btn_view_notes = (Button)findViewById(R.id.btn_view_notes);
      
        
        Button btn_student_exit = (Button)findViewById(R.id.btn_student_exit);
        
        btn_view_notes.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				LoggerEntity.setAction("VIEWNOTES");
				finish();
				Intent intent = new Intent(StudentMenu.this,StaffIdSelection.class);
				startActivity(intent);
			}
		});
        
     

        
    }
    
    
    private String getQuestion(String userid){
    	try{
            ArrayList<BasicNameValuePair> namevaluepair=new ArrayList<BasicNameValuePair>();
            namevaluepair.add(new BasicNameValuePair("staffId", userid));
           
            
            
            
                      
            HttpClient client=new DefaultHttpClient();
            HttpPost post=new HttpPost("http://"+LoggerEntity.getIpaddress()+":8080/CollegeApp/StudentAnswers.jsp");
            post.setEntity(new UrlEncodedFormEntity(namevaluepair));
            HttpResponse response=client.execute(post);
            HttpEntity entity=response.getEntity();
            InputStream in=entity.getContent();
            try{
                BufferedReader bf=new BufferedReader(new InputStreamReader(in));
                StringBuilder sb=new StringBuilder();
                String line=null;
                while((line=bf.readLine())!=null){

                    sb.append(line);

                }
                String result=sb.toString().trim();
              //  Toast.makeText(getApplicationContext(), "Result..."+result,Toast.LENGTH_SHORT).show();
              return result;
            }catch(Exception e){
                e.printStackTrace();
            }
        }catch(Exception e){
            System.out.println("Error in http"+e.toString());
        }
    	return null;
    }

}
