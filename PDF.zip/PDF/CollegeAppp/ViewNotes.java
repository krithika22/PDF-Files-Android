package com.CollegeAppp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ViewNotes  extends Activity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewnotes);
        
       Button btn_back = (Button)findViewById(R.id.btn_back);
        final TextView txt_file_content = (TextView)findViewById(R.id.txt_file_content);
        txt_file_content.setText(LoggerEntity.getFileContent());
        btn_back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			    finish();
			    Intent intent = new Intent(ViewNotes.this,StudentMenu.class);
			    startActivity(intent);
			}
		});
    }

}
