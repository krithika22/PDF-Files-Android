package com.CollegeAppp;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;


import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ViewBrowser extends Activity {
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.webkit);
	        WebView mWebView = (WebView)findViewById(R.id.webView1);
	        mWebView.getSettings().setJavaScriptEnabled(true);
	        mWebView.loadUrl(LoggerEntity.geturl());  
	 }

}
